﻿# Sistema RAVE - instalacion en Windows 10/11 (no necesita permisos de administrador)
$ErrorActionPreference = 'Stop'
$script:fallo = $false
try {
  $origen  = Split-Path -Parent $MyInvocation.MyCommand.Path
  $destino = 'C:\SistemaRAVE'
  $perfil  = Join-Path $destino 'perfil'
  Write-Host ''
  Write-Host '  SISTEMA RAVE - instalacion' -ForegroundColor Yellow
  Write-Host '  ---------------------------'
  New-Item -ItemType Directory -Force -Path $destino | Out-Null
  New-Item -ItemType Directory -Force -Path $perfil  | Out-Null
  foreach ($f in @('sistema-rave.html', 'rave.ico', 'actualizar.ps1', 'ACTUALIZAR.bat', 'desinstalar.ps1', 'DESINSTALAR.bat', 'LEEME.txt')) {
    Copy-Item (Join-Path $origen $f) $destino -Force
  }
  Write-Host '  Archivos copiados en C:\SistemaRAVE' -ForegroundColor Green

  $candidatos = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  $nav = $null
  foreach ($c in $candidatos) { if ($c -and (Test-Path $c)) { $nav = $c; break } }
  if (-not $nav) { throw 'No encontre Microsoft Edge ni Google Chrome en esta PC.' }

  # Ventana propia, sin barra de direcciones, con un perfil solo para el sistema:
  # si alguien borra el historial del navegador, los datos del sistema no se tocan.
  $url = 'file:///C:/SistemaRAVE/sistema-rave.html#panel'
  $argumentos = "--app=$url --user-data-dir=`"$perfil`" --no-first-run --no-default-browser-check"

  $shell = New-Object -ComObject WScript.Shell
  $lugares = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
  foreach ($dir in $lugares) {
    $lnk = $shell.CreateShortcut((Join-Path $dir 'Sistema RAVE.lnk'))
    $lnk.TargetPath       = $nav
    $lnk.Arguments        = $argumentos
    $lnk.WorkingDirectory = $destino
    $lnk.IconLocation     = (Join-Path $destino 'rave.ico')
    $lnk.Description      = 'Sistema RAVE - gestion del comercio'
    $lnk.Save()
  }
  Write-Host '  Acceso directo creado en el Escritorio y en el menu Inicio' -ForegroundColor Green
  Write-Host ''
  Write-Host '  Listo. Se abre el sistema.' -ForegroundColor Yellow
  Write-Host '  - Primera vez: asistente para crear el comercio, o "Conectar este dispositivo a la nube".'
  Write-Host '  - Para traer la ultima version: C:\SistemaRAVE\ACTUALIZAR.bat'
  Write-Host ''
  Start-Process -FilePath $nav -ArgumentList $argumentos
}
catch {
  $script:fallo = $true
  Write-Host ''
  Write-Host ('  ERROR: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  No se instalo. Mandale una foto de esta ventana a soporte.'
}
if ($script:fallo) { exit 1 } else { exit 0 }
