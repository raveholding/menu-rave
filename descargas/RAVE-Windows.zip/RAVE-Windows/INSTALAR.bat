@echo off
title Sistema RAVE
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0archivos\instalar.ps1"
if errorlevel 1 (
  echo.
  pause
) else (
  timeout /t 3 /nobreak >nul
)
