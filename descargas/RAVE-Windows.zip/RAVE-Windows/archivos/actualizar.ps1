﻿# Sistema RAVE - trae la ultima version publicada (los datos no se tocan)
$ErrorActionPreference = 'Stop'
$script:fallo = $false
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $destino = 'C:\SistemaRAVE'
  $tmp = Join-Path $env:TEMP 'rave-nuevo.html'
  Write-Host ''
  Write-Host '  Descargando la ultima version del Sistema RAVE...' -ForegroundColor Yellow
  Invoke-WebRequest -UseBasicParsing -Uri ('https://raveholding.github.io/menu-rave/index.html?v=' + [DateTime]::Now.Ticks) -OutFile $tmp
  $texto = Get-Content -Raw -Encoding UTF8 $tmp
  if ($texto.Length -lt 500000 -or $texto -notmatch 'SISTEMA <em>RAVE</em>') {
    throw 'Lo que se descargo no parece el Sistema RAVE. No se cambio nada.'
  }
  $actual = Join-Path $destino 'sistema-rave.html'
  if (Test-Path $actual) { Copy-Item $actual (Join-Path $destino 'sistema-rave.anterior.html') -Force }
  Move-Item $tmp $actual -Force
  Write-Host '  Actualizado. Cerra la ventana del sistema y volve a abrirla.' -ForegroundColor Green
  Write-Host '  (La version anterior quedo guardada como sistema-rave.anterior.html)'
}
catch {
  $script:fallo = $true
  Write-Host ('  ERROR: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Revisa que haya internet y proba de nuevo.'
}
if ($script:fallo) { exit 1 } else { exit 0 }
