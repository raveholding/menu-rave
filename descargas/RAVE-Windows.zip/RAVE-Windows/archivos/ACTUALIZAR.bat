@echo off
title Sistema RAVE
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\actualizar.ps1"
if errorlevel 1 (
  echo.
  pause
) else (
  timeout /t 4 /nobreak >nul
)
