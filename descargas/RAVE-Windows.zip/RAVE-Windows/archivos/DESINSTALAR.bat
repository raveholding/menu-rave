@echo off
title Sistema RAVE
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\desinstalar.ps1"
echo.
pause
