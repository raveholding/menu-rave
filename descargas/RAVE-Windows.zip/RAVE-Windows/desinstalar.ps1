﻿# Sistema RAVE - quita los accesos directos (los datos quedan, salvo que digas que no)
$ErrorActionPreference = 'Continue'
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $l = Join-Path $dir 'Sistema RAVE.lnk'
  if (Test-Path $l) { Remove-Item $l -Force }
}
Write-Host ''
Write-Host '  Accesos directos quitados.' -ForegroundColor Green
Write-Host '  Los datos de ESTE equipo estan en C:\SistemaRAVE\perfil (cifrados).'
Write-Host '  Si el comercio esta conectado a la nube, igual siguen en la nube.'
$r = Read-Host '  Escribi BORRAR para eliminar tambien los datos de este equipo (Enter para conservarlos)'
if ($r -eq 'BORRAR') {
  Remove-Item 'C:\SistemaRAVE\perfil' -Recurse -Force
  Write-Host '  Datos de este equipo eliminados.' -ForegroundColor Yellow
} else {
  Write-Host '  Datos conservados.'
}
